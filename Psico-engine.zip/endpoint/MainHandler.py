from tornado.web import Application, RequestHandler
from tornado.ioloop import IOLoop
import inscripcion.Core as form
import time


class MainHandlerVision(RequestHandler):
    def get(self):
        print('Request from host = ' + self.request.host)
        print('Request from ip = ' + self.request.remote_ip)
        try:
            data = form.Form.get_prediction(self,self.get_argument('numero_documento'),form.Form.open_database_sources(self),self.get_argument('tipo_documento'))
            RequestHandler.write(self,data)
            print('The method ' + self.request.method + ' for ' + form.Form.get_prediction.__name__ + ' ran in ' + str(self.request.request_time()) + ' seconds with status ' + str(self.get_status()))
        except Exception as e:
            if e.args[0]==500:
                RequestHandler.set_status(self, e.args[0], e.args[1])
                print('The method ' + self.request.method + ' for ' + form.Form.get_prediction.__name__ + ' ran in ' + str(self.request.request_time()) + ' seconds with status ' + str(self.get_status()))
                RequestHandler.write(self, {'message': 'Error internal server','timetamp': time.strftime('%Y-%m-%d %H:%M:%S')})
            else:
                print('The method ' + self.request.method + ' for ' + form.Form.get_prediction.__name__ + ' ran in ' + str(self.request.request_time()) + ' seconds with status ' + str(self.get_status()))


class MainHandlerForm(RequestHandler):
    def post(self):
        print('Request from host = ' + self.request.host)
        print('Request from ip = ' + self.request.remote_ip)
        aspirante = {'tipo_documento':self.get_argument('tipo_documento'),
                     'numero_documento':self.get_argument('numero_documento'),
                     'nombre':self.get_argument('nombre'),
                     'edad':self.get_argument('edad'),
                     'direccion':self.get_argument('direccion'),
                     'cargo':self.get_argument('cargo')}
        try:
            form.Form.save_asp(self,form.Form.open_database_sources(self), aspirante)
            print('The method ' + self.request.method + ' for ' + form.Form.save_asp.__name__ + ' ran in ' + str(self.request.request_time()) + ' seconds with status ' + str(self.get_status()))
            data = {
                'message':'Registro insertado'
            }
            RequestHandler.write(self,data)
        except Exception as e:
            if e.args[0]==500:
                RequestHandler.set_status(self, e.args[0], e.args[1])
                print('The method ' + self.request.method + ' for ' + form.Form.save_asp.__name__ + ' ran in ' + str(self.request.request_time()) + ' seconds with status ' + str(self.get_status()))
                RequestHandler.write(self, {'message': 'Error internal server','timetamp': time.strftime('%Y-%m-%d %H:%M:%S')})
            else:
                print('The method ' + self.request.method + ' for ' + form.Form.save_asp.__name__ + ' ran in ' + str(self.request.request_time()) + ' seconds with status ' + str(self.get_status()))

    def get(self):
        print('Request from host = ' + self.request.host)
        print('Request from ip = ' + self.request.remote_ip)
        aspirante = {'tipo_documento': self.get_argument('tipo_documento'),
                     'numero_documento': self.get_argument('numero_documento')
                     }
        try:
            data = form.Form.get_asp(self, form.Form.open_database_sources(self), aspirante)
            RequestHandler.write(self,data)
            print('The method ' + self.request.method + ' for ' + form.Form.get_asp.__name__ + ' ran in ' + str(self.request.request_time()) + ' seconds with status ' + str(self.get_status()))
        except Exception as e:
            if e.args[0]==500:
                RequestHandler.set_status(self, e.args[0], e.args[1])
                print('The method ' + self.request.method + ' for ' + form.Form.save_asp.__name__ + ' ran in ' + str(self.request.request_time()) + ' seconds with status ' + str(self.get_status()))
                RequestHandler.write(self, {'message': 'Error internal server','timetamp': time.strftime('%Y-%m-%d %H:%M:%S')})
            else:
                print('The method ' + self.request.method + ' for ' + form.Form.save_asp.__name__ + ' ran in ' + str(self.request.request_time()) + ' seconds with status ' + str(self.get_status()))

def make_app():
    urls = [
        (r"/vision", MainHandlerVision),
        (r"/vision/guardar", MainHandlerForm)
    ]
    return Application(urls, debug=True)


if __name__ == '__main__':
    app = make_app()
    app.listen(3001)
    IOLoop.instance().start()