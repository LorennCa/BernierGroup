import io
import os
from google.cloud import vision
from google.cloud.vision import types
import json

os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = "C:/Users/Lorena/Documents/Images/client_secret.json"
client = vision.ImageAnnotatorClient()
class VisionCore:

    def prediction(self,path):
        nombre_archivo = os.path.join(
            os.path.dirname(__file__),
            'C:/Users/Lorena/Documents/Images/'+path+'.jpg'
        )

        with io.open(nombre_archivo, 'rb') as nombre_archivo:
            content = nombre_archivo.read()

        image = vision.types.Image(content=content)

        response = client.face_detection(image=image)
        faces = response.face_annotations

        # Names of likelihood from google.cloud.vision.enums
        likelihood_name = ('DESCONOCIDO', 'NO MUY PROBABLE', 'NO PROBABLE', 'POSIBLE', 'PROBABLE', 'MUY PROBABLE')
        objects = client.object_localization(
            image=image).localized_object_annotations
        objetos = ""
        print('Number of objects found: {}'.format(len(objects)))
        for object_ in objects:
            print('\n{} (confidencett: {})'.format(object_.name, object_.score))
            print('Normalized bounding polygon vertices: ')
            objetos = objetos + object_.name + ","
            print(objetos[:len(objetos)-1])
            for vertex in object_.bounding_poly.normalized_vertices:
                print(' - ({}, {})'.format(vertex.x, vertex.y))

        for face in faces:
            data = {
                'ira':likelihood_name[face.anger_likelihood],
                'alegria':likelihood_name[face.joy_likelihood],
                'sorpresa':likelihood_name[face.surprise_likelihood],
                'dolor':likelihood_name[face.sorrow_likelihood],
                'confidence':[face.detection_confidence][0],
                'landmarking_confidence':[face.landmarking_confidence][0],
                'objetos':objetos[:len(objetos)-1]

            }

        return data


