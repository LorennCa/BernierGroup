import mysql.connector
from mysql.connector.errors import DatabaseError, IntegrityError, InterfaceError
import common.Error as error
import VisionAPI.VisionAPI as vision

class Form:
    def open_database_sources(self):
        try:
            db_sources = mysql.connector.connect(
                host='localhost',
                user='root',
                passwd='root',
                database='vision_database',
            )
        except InterfaceError as e:
            raise ConnectionError(500, error.P_500)
        return db_sources

    def save_asp(self, db_sources, aspirante):
        """This method storage the aspirants"""
        cursor = db_sources.cursor()
        try:
            INS__SQL_QUERY = "INSERT INTO aspirante (tipo_doc, num_doc, nombre, edad, direccion) VALUES (%s, %s, %s, %s,%s)"
            INSERT_VALUES = (aspirante['tipo_documento'],aspirante['numero_documento'],aspirante['nombre'],aspirante['edad'],aspirante['direccion'])
            cursor.execute(INS__SQL_QUERY, INSERT_VALUES)
            db_sources.commit()

            INS__SQL_QUERY_CARGO = "INSERT INTO cargo_aspirante (tipo_doc, num_doc, cargo) VALUES (%s, %s, %s)"
            INSERT_VALUES_CARGO = (
            aspirante['tipo_documento'], aspirante['numero_documento'], aspirante['cargo'])
            cursor.execute(INS__SQL_QUERY_CARGO, INSERT_VALUES_CARGO)
            db_sources.commit()
        except Exception as e:
            raise ConnectionError(500, error.P_500)
        return cursor.rowcount, "record inserted."

    def get_asp(self,db_sources, aspirante):
        cursor = db_sources.cursor()
        try:
            QUERY_SELECT_ASPIRANTE = "SELECT a.tipo_doc, a.num_doc, a.nombre, c.cargo, r.ira, r.alegria, r.sorpresa, r.dolor, r.confidence, r.landmarking FROM aspirante a, cargo_aspirante c, resultados_vision r WHERE a.tipo_doc = c.tipo_doc AND a.num_doc = c.num_doc AND r.tipo_doc = a.tipo_doc AND r.num_doc = a.num_doc and a.tipo_doc = '"+aspirante['tipo_documento']+"' AND a.num_doc = '"+aspirante['numero_documento']+"'"
            cursor.execute(QUERY_SELECT_ASPIRANTE)
            RESULT_ASPIRANTE = cursor.fetchall()
            if len(RESULT_ASPIRANTE)>0:
                for x in RESULT_ASPIRANTE:
                    data ={'tipo_documento':x[0],
                           'numero_documento':x[1],
                           'nombre':x[2],
                           'cargo':x[3],
                           'ira':x[4],
                           'alegria':x[5],
                           'sorpresa':x[6],
                           'dolor':x[7],
                           'confidence':x[8],
                           'landmarking':x[9]}
            else:
                data={'message':'No content'}
        except Exception as e:
            raise ConnectionError(500, error.P_500)
        return data

    def get_prediction(self, id_aspirante,db_sources, tipo_documento):
        cursor = db_sources.cursor()
        try:
            QUERY_SELECT = "SELECT tipo_doc, num_doc FROM aspirante WHERE tipo_doc = '"+tipo_documento+"' AND num_doc = '"+id_aspirante+"'"
            cursor.execute(QUERY_SELECT)
            RESULT_QUERY = cursor.fetchall()
            if len(RESULT_QUERY)>0:
                data = vision.VisionCore.prediction(self, id_aspirante)
                INS__SQL_QUERY = "INSERT INTO resultados_vision (tipo_doc, num_doc, ira, alegria, sorpresa, dolor, confidence,landmarking,objetos) VALUES (%s, %s, %s, %s,%s,%s, %s, %s, %s)"
                INSERT_VALUES = (
                tipo_documento,
                id_aspirante,
                data['ira'],
                data['alegria'],
                data['sorpresa'],
                data['dolor'],
                data['confidence'],
                data['landmarking_confidence'],
                data['objetos'])
                cursor.execute(INS__SQL_QUERY, INSERT_VALUES)
                db_sources.commit()
            else:
                data = {
                    'message':'No content for '+tipo_documento+id_aspirante
                }
        except Exception as e:
            raise ConnectionError(500, error.P_500)
        return data



